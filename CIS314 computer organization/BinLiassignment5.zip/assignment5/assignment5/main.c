//
//  main.c
//  assignment5
//
//  Created by Bin Li on 2/22/17.
//  Copyright © 2017 Bin Li. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    
}


getNumOnes(int n){
    
}
