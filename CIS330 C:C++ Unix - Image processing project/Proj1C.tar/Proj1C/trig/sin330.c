#include <math330.h>
#include <math.h>

double sin330(double angle)
{
    return sin(angle);
}
